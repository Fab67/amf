<?php

namespace App\Http\Controllers;

use App\Models\Article;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SaveController extends Controller
{
    public function create()
    {

         request()->validate([
            'categorie_id'=>['required'],
            'titre'=>['required'],
            'p1'=>['required'],
            'im1'=>['required','image'],
            'titreim1'=>['required'],
            'im2'=>['required','image'],
            'titreim2'=>['required'],

         ] );

         $filename=time().'.'.request('im1')->extension();
         $path=request()->file('im1')->storeAs(
              'Avatars',
              $filename,
              'public'
          );
          $filename1=time().'.'.request('im2')->extension();
          $path1=request()->file('im2')->storeAs(
               'Avatars',
               $filename1,
               'public'
           );

        Auth::user()->articles()->create([
            'categorie_id'=>request('categorie_id'),
            'titre'=>request('titre'),
            'aperçue'=>request('aperçue'),
            'titre_p1'=>request('titrep1'),
            'p1'=>request('p1'),
            'titre_p2'=>request('titrep2'),
            'p2'=>request('p2'),
            'titre_p3'=>request('titrep3'),
            'p3'=>request('p3'),
            'titre_im1'=>request('titreim1'),
            'im1'=>$path,
            'titre_im2'=>request('titreim2'),
            'im2'=>$path1,


        ]);
       #$eco= Filiere::all();
        #$ecole=Filiere::find(1)->filieres;
return redirect('/information') ;
    }


    public function affiche(){

        $type=request('type');
        $idz=request('info_id');
        $id=decrypt($idz);


        $infos=Article::all();
      $info=$infos->where('id',$id)->first();


        $post = Article::latest ()->get();
        #dd($post);
        for ($j=0; $j<2;$j++){
        $gost[]=$post[$j];
        }


      $relation=$info->categorie->id;
      $rel = Article::where('categorie_id', $relation)->latest ()->get();
    #  dd($rel);
        for ($j=0; $j<4;$j++){
            $rel2[]=$rel[$j];
            }

        return view('page',[
            "article"=>$gost,
            'info'=>$info,
            'relation'=>$rel2,
            'idc'=>$relation,
            'type'=>$type
        ]);
    }

}
