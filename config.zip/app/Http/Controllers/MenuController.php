<?php

namespace App\Http\Controllers;

use App\Models\Article;
use Illuminate\Http\Request;

class MenuController extends Controller
{
    public function menu(){

        $ida=request('menu');
        $id=decrypt($ida);

        $type=request('type');
        $post = Article::latest ()->where('categorie_id',$id)->get();
        #dd($post);
        for ($j=0; $j<12;$j++){
        $gost[]=$post[$j];
        }

        return view('afrique',[
            "article"=>$gost,
            "type"=>$type
        ]);
    }
}
