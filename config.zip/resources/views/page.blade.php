
    @extends ('layouts.new')

    @section('menu')
    <div data-tms-ad-container="" class="o-ad-container o-ad-container--banner-top o-ad-container--with-background">
        <div class="o-ad-container__content o-ad-container__content--report-enabled">
            <div class="o-ad-container__content__ad" data-tms-ad-type="banner" data-tms-ad-status="idle" data-tms-ad-pos="1"></div>
                            <button title="Signaler cette publicité" class="o-ad-container__content__report-link" rel="noopener" data-tms-ad-report=""><svg xmlns="http://www.w3.org/2000/svg" width="26.077" height="16.107"><g fill="none" stroke="currentColor"><path d="M7.994 15.607a1.5 1.5 0 0 1-1.5-1.5v-3.423H1.325l5.169-4.547V2a1.5 1.5 0 0 1 1.5-1.5h16.083a1.5 1.5 0 0 1 1.5 1.5v12.107a1.5 1.5 0 0 1-1.5 1.5z"></path><g stroke-width="2"><path d="M16.037 10.504v-7.84M16.037 13.442V11.71"></path></g></g></svg></button>
           </div>
    </div>
    <div class="o-ad-sponsoring" data-tms-ad-type="sponsoring" data-tms-ad-status="disabled">
    <a class="o-ad-sponsoring__link o-ad-sponsoring__start start_link" href=""></a>
    <a class="o-ad-sponsoring__link o-ad-sponsoring__middle middle_link" href=""></a>
    <a class="o-ad-sponsoring__link o-ad-sponsoring__end end_link" href=""></a>
    </div>
    <link type="text/css" rel="stylesheet" href="">
    <div class="t-content t-content--page-builder">
    <div id="main-content" tabindex="-1"></div>

    <article data-article-content>
            <div id="main-content" tabindex="-1"></div>
            <div class="o-layout-list ">
                        <div class="t-content__section a-tag">
                             <span class="a-tag__wrapper">
                            {{$type}}
                             </span><br>
                        </div>

                      <h1 class="t-content__title a-page-title">{{$info->titre}}</h1>
                      <div class="t-content__shares">
                         <div class="m-share-bar">

                             <a href="" class="m-share-bar__link m-share-bar__link--desktop a-picto-social svg" target="_blank" rel="noopener nofollow" aria-label="WhatsApp">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="624 93 45 45"><path d="M664.516 138h-36.032a4.457 4.457 0 0 1-3.174-1.31 4.457 4.457 0 0 1-1.31-3.174V97.484a4.457 4.457 0 0 1 1.31-3.174 4.457 4.457 0 0 1 3.174-1.31h36.032a4.457 4.457 0 0 1 3.174 1.31 4.457 4.457 0 0 1 1.31 3.174v36.032a4.457 4.457 0 0 1-1.31 3.174 4.457 4.457 0 0 1-3.174 1.31zm-17.837-38a15.575 15.575 0 0 0-15.552 15.544 15.54 15.54 0 0 0 2.077 7.769l-2.2 8.059 8.247-2.158a15.546 15.546 0 0 0 7.432 1.89h.008a15.576 15.576 0 0 0 15.552-15.545 15.523 15.523 0 0 0-4.557-11A15.461 15.461 0 0 0 646.679 100zm0 28.474a12.92 12.92 0 0 1-6.581-1.8l-.471-.276-4.892 1.284 1.307-4.766-.306-.485a12.9 12.9 0 0 1-1.979-6.88 12.941 12.941 0 0 1 12.93-12.923 12.811 12.811 0 0 1 9.135 3.787 12.846 12.846 0 0 1 3.787 9.143 12.947 12.947 0 0 1-12.93 12.917zm-5.49-20.1a1.425 1.425 0 0 0-1.039.485l-.072.077a4.278 4.278 0 0 0-1.287 3.165 7.432 7.432 0 0 0 1.577 4.011l.006.008.064.091a16.768 16.768 0 0 0 6.577 5.774 21.7 21.7 0 0 0 2.219.822 4.859 4.859 0 0 0 1.5.23 6.564 6.564 0 0 0 .945-.073 3.985 3.985 0 0 0 2.622-1.845 3.212 3.212 0 0 0 .224-1.845 1.32 1.32 0 0 0-.564-.378l-.19-.093c-.465-.233-2.311-1.139-2.651-1.263a1.317 1.317 0 0 0-.418-.1.54.54 0 0 0-.457.293c-.259.386-.986 1.247-1.232 1.524a.531.531 0 0 1-.418.223.974.974 0 0 1-.426-.126c-.064-.032-.15-.069-.258-.116a10.048 10.048 0 0 1-2.864-1.811 11.609 11.609 0 0 1-2.159-2.689c-.227-.393-.015-.605.172-.792.11-.11.241-.269.368-.422.072-.088.146-.177.216-.257a2.2 2.2 0 0 0 .345-.56l.043-.089a.719.719 0 0 0-.03-.68 89.758 89.758 0 0 1-.827-1.988v-.012l-.363-.884c-.257-.614-.518-.666-.743-.666h-.131c-.226-.014-.492-.014-.749-.014z" fill="#25d366"/>
                                </svg>
                             </a>

                                <span class="m-share-bar__link" data-root-share>
                            <share-button v-on:open="openModal" aria-label="Partager"></share-button>
                            <share-modal v-if="displayModal" v-on:close="closeModal"></share-modal>
                        </span>
                    </div>
                    </div>

                    <div class="t-content__dates">
                            <p class="m-pub-dates"><span class="m-pub-dates__date">Publié le :
                                <time datetime="2022-10-26T05:50:05+00:00" pubdate="pubdate">{{$info->created_at}}</time></span>
                            </p><br>
                    </div>



                        <img src="{{Storage::url($info->im2)}}" alt="" class="responsive">

                        <span class="a-media-legend">{{$info->titre_im1}}</span><br><br>

               <!-- <div class="t-content__authors-tts">
                  <div class="m-author-n-reading-time">
                        <div class="m-author-n-reading-time__authors">
                            <div class="m-from-author">
                                 <span class="m-from-author__by-label"> Texte par : </span>
                                 <a href="" title="" class="m-from-author__name"> Louise BROSOLO  </a>
                            </div>
                        </div>

                 </div>
              </div>-->

             <p class="t-content__chapo">
                {{$info->aperçue}}
             </p>

            <div class="t-content__body u-clearfix">
               <!-- <div class="m-interstitial">
                      <div data-readmore-target class="m-interstitial__ad">
                         <div class="m-block-ad " data-tms-ad-type="box"  data-tms-ad-status="idle" data-tms-ad-pos="1">
                              <div class="m-block-ad__label m-block-ad__label--report-enabled">
                                  <span class="m-block-ad__label__text">Publicité</span>
                                  <button title="Signaler cette publicité" class="m-block-ad__label__report-link" rel="noopener" data-tms-ad-report><svg xmlns="http://www.w3.org/2000/svg" width="26.077" height="16.107"><g fill="none" stroke="currentColor"><path d="M7.994 15.607a1.5 1.5 0 0 1-1.5-1.5v-3.423H1.325l5.169-4.547V2a1.5 1.5 0 0 1 1.5-1.5h16.083a1.5 1.5 0 0 1 1.5 1.5v12.107a1.5 1.5 0 0 1-1.5 1.5z"/><g stroke-width="2">
                                    <path d="M16.037 10.504v-7.84M16.037 13.442V11.71"/></g></g></svg></button>
                              </div>
                               <div class="m-block-ad__content"> </div>
                          </div>
                      </div>

               </div>-->

               <h2> <strong>{{$info->titre_p1}}</strong> </h2>
               <p>
                {{$info->p1}}
                </p>
                <img src="{{Storage::url($info->im2)}}" alt="" class="responsive">

                        <span class="a-media-legend">{{$info->titre_im1}}</span><br><br>
                <h2> <strong>{{$info->titre_p2}}</strong> </h2>
                <p>
                    {{$info->p2}}
                </p>

                <h2> <strong>{{$info->titre_p3}}</strong> </h2>
                <p>
                    {{$info->p3}}
                </p>


            </div>
    </div>
</article>



            <!--TECH-->

            <section class="t-content__section-pb">
                <aside data-org-name="Afrique" data-org-type="aside-content--sponsors" class="o-aside-content  o-aside-content--no-background">

                    <div class="o-aside-content__row o-aside-content__row--center">
                        <div class="o-aside-content__title a-aside-title"><span class="a-aside-title__content">AUTRES</span></div>
                    </div>

                    <div class="o-layout-list ">
                         <div class="o-layout-list__item l-m-100 l-t-50 l-d-33">
                              <div class="m-item-list-article  m-item-list-article--hor-to-ver" data-article-list="">
                                 <a href="{{route('pag', ["info_id"=>encrypt($relation[1]->id),'type'=>$type])}}" data-article-item-link="" data-tms-tr="">
                                      <div class="article__figure-wrapper">
                                          <figure class="m-figure m-figure--16x9 ">
                                              <picture>
                                                  <img src="{{Storage::url($relation[1]->im1)}}" alt="Tchad: Saleh Kebzabo, l&#39;opposant historique à Idriss Déby, nommé Premier ministre" aria-hidden="true" sizes="(max-width: 639px) calc(37vw - 32px), (max-width: 1023px) calc(50vw - 36px), (min-width: 1024px) 306px" loading="lazy" class="m-figure__img lazy" data-ll-status="native">
                                              </picture>
                                          </figure>
                                      </div>
                                      <div class="article__infos">
                                          <p class="article__title "><span class="article__type"><svg xmlns="http://www.w3.org/2000/svg" viewBox="417 -2708 15.218 10.146" preserveAspectRatio="xMinYMin meet" class="picto--video"><path d="M428.836-2704.2v-2.955a.845.845 0 0 0-.845-.845h-10.146a.845.845 0 0 0-.845.845v8.455a.845.845 0 0 0 .845.845h10.146a.845.845 0 0 0 .845-.845v-2.959l3.382 3.382v-9.3z">
                                            </path></svg></span>{{$relation[1]->titre}}</p>
                                      </div>
                                  </a>
                              </div>
                         </div>

                         <div class="o-layout-list__item l-m-100 l-t-50 l-d-33">
                             <div class="m-item-list-article  m-item-list-article--hor-to-ver" data-article-list="">
                                 <a href="{{route('pag', ["info_id"=>encrypt($relation[0]->id),'type'=>$type])}}" data-article-item-link="" data-tms-tr="">
                                     <div class="article__figure-wrapper">
                                         <figure class="m-figure m-figure--16x9 ">
                                             <picture>
                                                 <img src="{{Storage::url($relation[0]->im1)}}" alt="Inondations au Nigeria" aria-hidden="true" sizes="(max-width: 639px) calc(37vw - 32px), (max-width: 1023px) calc(50vw - 36px), (min-width: 1024px) 306px" loading="lazy" class="m-figure__img lazy" data-ll-status="native">
                                             </picture>
                                         </figure>
                                     </div>
                                    <div class="article__infos">
                                        <p class="article__title ">{{$relation[0]->titre}}</p>
                                    </div>
                               </a>
                            </div>
                        </div>

                        <div class="o-layout-list__item l-m-100 l-t-50 l-d-33">
                            <div class="m-item-list-article  m-item-list-article--hor-to-ver" data-article-list="">
                                <a href="{{route('pag', ["info_id"=>encrypt($relation[3]->id),'type'=>$type])}}" data-article-item-link="" data-tms-tr="">
                                     <div class="article__figure-wrapper">
                                          <figure class="m-figure m-figure--16x9 ">
                                               <picture>
                                                   <img src="{{Storage::url($relation[3]->im1)}}" alt="000_32LA3PT" aria-hidden="true" sizes="(max-width: 639px) calc(37vw - 32px), (max-width: 1023px) calc(50vw - 36px), (min-width: 1024px) 306px" loading="lazy" class="m-figure__img lazy" data-ll-status="native">
                                              </picture>
                                          </figure>
                                      </div>
                                      <div class="article__infos">
                                            <p class="article__title ">{{$relation[3]->titre}}</p>
                                      </div>
                               </a>
                            </div>
                      </div>
                    </div>

                            <div class="o-aside-content__row o-aside-content__row--flex-end">
                                <a class="o-aside-content__see-more" href="{{route($type,['menu'=>encrypt($idc),'type'=>$type])}}" data-tms-tr="">
                                    Lire plus d'actualités  <span class="svg"><svg xmlns="http://www.w3.org/2000/svg" viewBox="1057.5 -2518.354 10.185 8.722"><path fill="none" stroke="currentColor" d="m1062.797-2517.999 4.168 4.143-4.168 3.857m3.655-3.907h-8.952"></path></svg></span>
                                </a>
                            </div>
                 </aside>
                 </section>




    @endsection
