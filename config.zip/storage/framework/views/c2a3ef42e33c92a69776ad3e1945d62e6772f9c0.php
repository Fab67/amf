<?php $__env->startSection('menu'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\news\resources\views/france.blade.php ENDPATH**/ ?>