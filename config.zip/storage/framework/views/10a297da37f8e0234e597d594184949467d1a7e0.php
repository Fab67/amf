<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


<section id="hero" class="hero d-flex align-items-center section-bg" style="background-color:#FFFFFF">
    <div class="container">
      <div class="row justify-content-between gy-5">
        <div class="col-lg-5 order-2 order-lg-1 d-flex flex-column justify-content-center align-items-center align-items-lg-start text-center text-lg-start">
          <h2  data-aos="fade-up">BIENVENUE DANS VOTRE COMPTE ADMIN</h2>
          <p data-aos="fade-up" data-aos-delay="100"></p>

            <p data-aos="fade-up" data-aos-delay="100">
                <i class="bi bi-check2-all"></i>  Enregistrer les actualités. <br>
                <i class="bi bi-check2-all"></i> People <br>
                <i class="bi bi-check2-all"></i> Cinéma <br>
                <i class="bi bi-check2-all"></i>  Musique<br>
                <i class="bi bi-check2-all"></i> News des stars <br>
                <i class="bi bi-check2-all"></i> Sport <br>
                <i class="bi bi-check2-all"></i>  Technologie<br>
                <i class="bi bi-check2-all"></i> Environnement <br>

         </p>

        </div>
        <div class="col-lg-5 order-1 order-lg-2 text-center text-lg-start">
          <img src="/boot2/assets/img/hero-img2.svg" class="img-fluid" alt="" data-aos="zoom-out" data-aos-delay="300">
        </div>
      </div>
    </div>
</section><!-- End Hero Section -->

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\DELL\news\resources\views/dashboard.blade.php ENDPATH**/ ?>