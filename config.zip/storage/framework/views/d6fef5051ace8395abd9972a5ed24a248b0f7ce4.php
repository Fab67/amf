<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section>
        <div class="card">
          <div class="card-body">

    <br><br>
            <!-- No Labels Form -->
            <form class="row g-3" method="POST" action="<?php echo e(route('save-info')); ?>" id="forme1"   enctype="multipart/form-data">
               <?php echo csrf_field(); ?>
                <select class="form-select" aria-label="Default select example" name="categorie_id">
                    <option selected>Selectionnez d'abord la catégorie</option>
                    <?php $__currentLoopData = @$cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cats->id); ?>"><?php echo e($cats->categorie); ?></option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>

                <h5 class="card-title">Informations</h5>
              <div class="mb-3">
                  <input type="text" class="form-control" id="inputText" placeholder="Titre" name="titre">
                  <?php if($errors->has('required')): ?>
                  <h6><?php echo e($errors->first('required')); ?> </h6>
              <?php endif; ?>
                </div><br><br>

                <div class="mb-3">
                  <label for="exampleFormControlTextarea1" class="form-label" >Brève aperçue de l'information </label>
                  <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="aperçue"></textarea>
                </div>

                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Paragraphe 1 </label>
                    <input type="text" class="form-control" id="inputText" placeholder="Titre du paragraphe 1" name="titrep1"><br>
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="p1"></textarea>
                  </div>

                  <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Paragraphe 2</label>
                    <input type="text" class="form-control" id="inputText" placeholder="Titre du paragraphe 2" name="titrep2"><br>
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="p2"></textarea>
                  </div>


                  <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Paragraphe 3</label>
                    <input type="text" class="form-control" id="inputText" placeholder="Titre du paragraphe 3" name="titrep3"><br>
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="p3"></textarea>
                  </div><br><br>

                  <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">image 1</label>
                    <input type="file" class="form-control" name="im1" ><br>
                    <input type="text" class="form-control" id="inputText" placeholder="Titre de l'image 1" name="titreim1">
                  </div><br><br>

                  <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">image 2</label>
                    <input type="file" class="form-control" name="im2" ><br>
                    <input type="text" class="form-control" id="inputText" placeholder="Titre de l'image 2" name="titreim2">
                  </div><br><br>

                  <div class="text-center">
                    <button type="submit"class="btn btn-info">Submit</button>
                        <button type="reset"class="btn btn-info">Reset</button>
                    </div><br>
            </form><!-- End No Labels Form -->

          </div>
        </div>



    </section>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\DELL\news\resources\views/dash.blade.php ENDPATH**/ ?>