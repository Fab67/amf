<H1>BONJOUR</H1><br><br>
<?php /**PATH C:\Users\DELL\news\resources\views/vendor/jetstream/components/welcome.blade.php ENDPATH**/ ?>